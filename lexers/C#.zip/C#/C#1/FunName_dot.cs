public class CutWithoutSelection : IEditTask, IEditTaskName
{
    void IEditTask.Activate(IEditor Editor, IEditTask oldTask)
    {
      if (Editor == null)
        return;
    }

  internal static g::S.R.R ResMan {
    get {
      if (object.RefEq(resourceMan, null)) { //------wrong treeItm
        aaa;
      }
    set {
    aaa
    }
  }

  internal static g::S.R.R ResMan22 {
    get {
      if (RefEq(resourceMan, null)) { //------wrong treeItm
        aaa;
      }
    set {
    aaa
    }
  }

}
}
}
