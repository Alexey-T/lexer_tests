<?php //Example

include "os.php";
include_once $path."/os2.php";
include("math.php");
include_once("math2.php");

function pp_out1(int $a){
  $a = 10;
  $b = 20;
  $this->var = 100;
  $this->proc($var);
  echo '\\';
  echo 'test'."\\";
  if (a){
  }
  else {
  };
}

class f {
  function a(){
    $n = 10;
    if (a) { a++; }
    i++;
  }
  function b(){
  }
}

class ff extends f {
  function a(){
    i++;
  }

  function b(){
    if (a>b) {
      a++;
    }
  }
}

function pp_out2($a; $b){
  $i++;
  if ($a){
  }
}

?>
