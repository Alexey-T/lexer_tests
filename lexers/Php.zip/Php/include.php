<?
function test(){
require $poll_path."/include/config.inc.php";
require $poll_path."/include/$POLLDB[class]";
require_once $poll_path."/include/class_poll.php";
require("poll/poll_cookie.php");
}
?>
