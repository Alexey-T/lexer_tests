
<?php
$output = `ls -al`;
$output = `ls -al`;
echo "<pre>$output</pre>";
?>
