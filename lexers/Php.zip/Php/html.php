<html>
<head>
<title>
<?php
dd();
?>
</title>
<body style='aaa; aaa; aaa; aaa;'>p*2
<style>
  back: ddddd; @i
</style>
</body>
</html>

