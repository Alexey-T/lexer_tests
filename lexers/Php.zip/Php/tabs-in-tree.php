<?php

	switch (m) {
		case 1: {test};
		case 2: {test};
	}
		

?>
