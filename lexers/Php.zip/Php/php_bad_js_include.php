<head>
<title>
<meta content="width=1024" name="viewport"/>
<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
<meta content="telephone=no" name="format-detection">

<script src="<?=SITE_TEMPLATE_PATH?>/js/jquery-1.8.2.min.js" type="text/javascript"></script>
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/jquery.carouFredSel-6.1.0-packed.js">
var n=10;
</script>
<script src="<?=SITE_TEMPLATE_PATH?>/js/main.js" type="text/javascript">
var n=10;
</script>
</head>
