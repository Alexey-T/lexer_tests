<?php

  if($status<>"") $attr.="&status=".$status;
  
  if (aa) {
    tt
  }  
  else {
    test
  };

  function get($campaign_id="",$status="",$list_id="",$type="") {
  }

?>
