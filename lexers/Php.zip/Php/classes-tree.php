<?php

function PPppp($i){
  $i=0;
  if (abs(1.0)){
  }
}

class f extends f__ {
  function a(){
    $i++;
  }
  function b(){
  }
}

class ff {
  function a(){
  }

  function b(){
    $f = 2;
    if ($a>$b){
      $a++;
    }
  }
}

function pp(){
  $i++;
  if (a){
  }
}

?>
