    var string = (<r><![CDATA[ 
     
       The text string goes here.  Since this is a XML CDATA section, 
       stuff like <> work fine too, even if definitely invalid XML.  
     
    ]]></r>).toString();  
    