/**
 * 
 * @author Artod http://artod.ru for ��� "�������� ���" http://expresslab.ru
 *
 */

$(document).ready(function(){




		
    var basket_china=$.cookie("basket_china");
    var basket_china_ForPHP4=$.cookie("basket_china_ForPHP4");    
    if(basket_china){
        basket_china=$.evalJSON(basket_china);
    }
    else{
        basket_china=new Object;
    }
    render_china();
    
    $("#china_basket_a").click(function(){
        
    	var china_basket='';        
                
        china_basket+=$(":radio[name=524]").filter(":checked").val();        
        var goods_china_name_1=$(":radio[name=524]").filter(":checked").next(".goods_name").text();
        var goods_china_ves_1=$(":radio[name=524]").filter(":checked").next().next().next(".ves").text();
        var goods_china_cost_1=$(":radio[name=524]").filter(":checked").next().next().next().next(".cost").text();        
        
        china_basket+=","+$(":radio[name=525]").filter(":checked").val();
        var goods_china_name_2=$(":radio[name=525]").filter(":checked").next(".goods_name").text();
        var goods_china_ves_2=$(":radio[name=525]").filter(":checked").next().next().next(".ves").text();
        var goods_china_cost_2=$(":radio[name=525]").filter(":checked").next().next().next().next(".cost").text();
        
        china_basket+=","+$(":radio[name=526]").filter(":checked").val();
        var goods_china_name_3=$(":radio[name=526]").filter(":checked").next(".goods_name").text();
        var goods_china_ves_3=$(":radio[name=526]").filter(":checked").next().next().next(".ves").text();
        var goods_china_cost_3=$(":radio[name=526]").filter(":checked").next().next().next().next(".cost").text();
        
        china_basket+=","+$(":radio[name=527]").filter(":checked").val();
        var goods_china_name_4=$(":radio[name=527]").filter(":checked").next(".goods_name").text();
        var goods_china_ves_4=$(":radio[name=527]").filter(":checked").next().next().next(".ves").text();
        var goods_china_cost_4=$(":radio[name=527]").filter(":checked").next().next().next().next(".cost").text();
		
        if(basket_china[china_basket]){
        	basket_china[china_basket].q++;        	
        }
        else{
        	basket_china[china_basket]={
            	n1:goods_china_name_1,
                v1:goods_china_ves_1,
                c1:goods_china_cost_1,
                n2:goods_china_name_2,
                v2:goods_china_ves_2,
                c2:goods_china_cost_2,
                n3:goods_china_name_3,
                v3:goods_china_ves_3,
                c3:goods_china_cost_3,
                n4:goods_china_name_4,
                v4:goods_china_ves_4,
                c4:goods_china_cost_4,
                q:1
            };                                 
        }
        
        save_china();
        $("body,html").animate({scrollTop:0},800);
		render_china();
		return false;        
    });
    
    $("a.basket_china_dec").live("click", function(){
		var id=$(this).attr("href").replace("#", "");		
		dec_china(id);
	});
	
	$("a.basket_china_inc").live("click", function(){
		var id=$(this).attr("href").replace("#", "");
		inc_china(id);
	});

	$("a.basket_china_del").live("click", function(){
		var id=$(this).attr("href").replace("#", "");
		if(!id){
			return false;
        }
		delete basket_china[id];        
		save_china();
		render_china();
		return false;
	});
	
	$("a.basket_china_clear").click(function(){
		delete basket_china;
		basket_china=new Object;
		save_china();
		$("#basket_china_show").css("display","none");
        render_china();
		return false;                
	});
	

	function dec_china(id){
		if(!id){
			return false;
        }
		basket_china[id].q--;
		save_china();
		render_china();
	}
	
	function inc_china(id){
		if(!id){
			return false;
        }
		basket_china[id].q++;        
		save_china();
		render_china();
	}
	
	function save_china(){
        $.cookie("basket_china",$.toJSON(basket_china),{expires:30,path:"/"});
	}
    
    function render_china(){
		
		$("#basket_china").html("");
		
        var b="";
		var s=0;
		var k=0;
        basket_china_ForPHP4='';
        
        var sum=0;
        var n=0;
        
		for(china_basket in basket_china){		
			if(basket_china[china_basket].q>0){
				var cl;
				var goods_china=basket_china[china_basket];
                if(basket_china){
                	basket_china_ForPHP4+=china_basket+'|'+goods_china.q+';';
                }				
				
				if(k){
					cl="basket-white";
					k=0;
				}
                else{
					cl="basket-grey";
					k=1;
				}
                
                sum=parseInt(goods_china.q)*(parseInt(goods_china.c1)+parseInt(goods_china.c2)+parseInt(goods_china.c3)+parseInt(goods_china.c4));
                n+=1;
				b+="<div class='"+cl+"'><table width='180' border='0' cellspacing='0' cellpadding='0'><tr><td valign='top'>������� �"+n+" ( <strong>"+sum+" ���.</strong> ) <a href='#"+china_basket+"' class='basket_china_del'><img style='float:right' src='images/delete.png' width='14' height='14' border='0' /></a><br /><a href='#"+china_basket+"' class='basket_china_dec'><img height='11' width='11' src='images/down.gif' alt='' /></a>"+goods_china.q+" ��.<a href='#"+china_basket+"' class='basket_china_inc'><img height='11' width='11' src='images/up.gif' alt='' /></a></td></tr><tr><td valign='top'>1) "+goods_china.n1+" ("+goods_china.v1+", "+goods_china.c1+" ���.)<br /></td></tr><tr><td valign='top'>2) "+goods_china.n2+" ("+goods_china.v2+", "+goods_china.c2+" ���.)<br /></td></tr><tr><td valign='top'>3) "+goods_china.n3+" ("+goods_china.v3+", "+goods_china.c3+" ���.)<br /></td></tr><tr><td valign='top'>4) "+goods_china.n4+" ("+goods_china.v4+", "+goods_china.c4+" ���.)<br /></td></tr></table></div>"				
				s=s+parseInt(goods_china.q)*(parseInt(goods_china.c1)+parseInt(goods_china.c2)+parseInt(goods_china.c3)+parseInt(goods_china.c4));
                $.cookie("basket_china_ForPHP4", $.toJSON(basket_china_ForPHP4),{expires:30,path:"/"});				
			}
            else{
				delete basket_china[china_basket];
			}
		}
			
		if(b){
        	var total="<div style='background-color:#fff; padding:10px 18px 0 18px;'>����� �� �����: <span style='font-size:18px;'>"+s+" ���.</span></div>";
			$("#basket_china").append(b+total);						
		}
        else{
			$("#basket_china").append("<div class='basket-grey_china'>������� �����</div>");
		}        
	}
    
    
    

    
    $('#basket_china_del_all').click(function(){
    	$.cookie('basket_china',null,{path:'/'});
        $('#basket_china_show').css("display","none");
    });

        



	var basket=$.cookie('basket');
	var basketForPHP4=$.cookie('basketForPHP4');
	if(basket) basket=$.evalJSON(basket); else basket=new Object;

	render();

	$('a.basket0, a.basket1').click(function(){
		var k=($(this).attr('class') == 'basket0' ? 0 : 1);
		var tmp=$(this).parent().parent().parent().parent().parent();
	
		var name=tmp.find('h3').text()+'('+tmp.find('span.ves'+k).text()+')';
		var cost=tmp.find('span.cost'+k).text();
		var id=$(this).attr('href').replace('#', '');
		
		if(basket[id]){
			basket[id].q++;
		}
        else{			
			basket[id]={
				n: name,
				c: cost,
				q: 1
			};
		}
		save();
		render();
		return false;
	});

	$('a.basket-dec').live('click', function(){
		var id=$(this).attr('href').replace('#', '');		
		dec(id);
	});
	
	$('a.basket-inc').live('click', function(){
		var id=$(this).attr('href').replace('#', '');
		inc(id);
	});

	$('a.basket-del').live('click', function(){
		var id=$(this).attr('href').replace('#', '');
		if(!id)
			return false;
		delete basket[id];
		save();
		render();
		return false;
	});
	
	$('#basket-clear').click(function(){
		delete basket;
		basket=new Object;
		save();
		render();
		return false;
	});
	

	function dec(id){
		if(!id)
			return false
		basket[id].q--;
		save();
		render();
	}
	
	function inc(id){
		if(!id)
			return false
		basket[id].q++;
		save();
		render();
	}
	
	function save(){
		$.cookie('basket', $.toJSON(basket),{path: '/'});
	}

	function render(){
		$('#basket').html('');
		var b='';
		var s=0;
		var k=0;
		basketForPHP4='';
		for(id in basket){
		
			if(basket[id].q>0){
				var cl;
				var goods=basket[id];
				basketForPHP4 += id+'|'+goods.q+';';
				
				if(k){
					cl='basket-white';
					k=0;
				} else{
					cl='basket-grey';
					k=1;
				}

				b=b+" \
					<div class='"+cl+"'> \
						<table width='180' border='0' cellspacing='0' cellpadding='0'> \
							<tr> \
								<td width='166' valign='top'> \
									"+goods.n+"<br /> \
									<a href='#"+id+"' class='basket-dec'><img height='11' width='11' src='images/down.gif' alt='' /></a> "+goods.q+" ��. <a href='#"+id+"' class='basket-inc'><img height='11' width='11' src='images/up.gif' alt='' /></a>  - <strong>"+goods.c+" ���.</strong> \
								</td> \
								<td width='14' valign='top'> \
									<a href='#"+id+"' class='basket-del'><img src='images/delete.png' width='14' height='14' border='0' vspace='4'/></a> \
								</td> \
							</tr> \
						</table> \
					</div> \
				";				
				s=s+parseInt(goods.q)*parseInt(goods.c);
				$.cookie('basketForPHP4', $.toJSON(basketForPHP4),{path: '/'});
			} else{
				delete basket[id];
			}
		}
			
		if(b){
			$('#basket').append(b+" \
				<div style='background-color:#fff; padding:10px 18px 0 18px;'> \
					����� �� �����: <span style='font-size:18px;'>"+s +" ���.</span> \
				</div> \
			");			
		}
        else{
			$('#basket').append("<div class='basket-grey'>������� �����</div>");
			$('#basket-handler').hide();
		}
	}

});