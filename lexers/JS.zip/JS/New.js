// example function
function SetEnabled(A,count)
{
  for(i= 0; i< count;i++)
    A(i).Enabled = !A(i).Enabled;
}
