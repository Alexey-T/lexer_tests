// Required by ../importing.coffee
module.exports = {value: function(){return 1;}};
