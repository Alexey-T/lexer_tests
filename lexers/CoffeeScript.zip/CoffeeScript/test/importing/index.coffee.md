Required by ../importing.coffee

    module.exports = {value: -> 3}
