-- comment --[[test22]] comment continue

--[[ comment]] not comment

--[=[
comment
comment
]=] not comment

not comment

--[[ comment
comment
comment end ]] not comment

