function test()
  MyTest() -- tt function
  if cond then
  end
end

-- (?<=function\x32+)[\w\.:]+
