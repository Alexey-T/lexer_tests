C["Misc"] = {
["enable"] = true,      -- Enable
["button_size"] = 27,      -- Buttons size
["button_space"] = 3,      -- Buttons space
["columns"] = 17,      -- Horizontal number of columns
["columns_1"] = 10,      -- Horizontal number of columns 1
}
