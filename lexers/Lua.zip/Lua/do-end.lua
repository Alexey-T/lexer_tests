
--[[ test
test
test
]]

do --test
  test
  test
  test
  for i=1, 1000 do
    test
    test
  end  
  test
  test
  test
  test
  test
end
  
