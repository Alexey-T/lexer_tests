    do
    
      function Test()
        nTest = 22
      end
      sTest = '777'
    end
    