import Color (..)
import Debug
import Graphics.Collage (..)
import Graphics.Element (..)
import Keyboard
import Signal
import Time (..)
import Window


-- MODEL

type alias Model =
    { x : Float
    , y : Float
    , vx : Float
    , vy : Float
    , dir : Direction
    }

type Direction = Left | Right

type alias Keys = { x:Int, y:Int }


mario : Model
mario =
    { x = 0
    , y = 0 
    , vx = 0
    , vy = 0
    , dir = Right
    }


-- UPDATE

update : (Float, Keys) -> Model -> Model
update (dt, keys) mario =
    mario
        |> gravity dt
        |> jump keys
        |> walk keys
        |> physics dt
        |> Debug.watch "mario"


jump : Keys -> Model -> Model
jump keys mario =
    if keys.y > 0 && mario.vy == 0
      then { mario | vy <- 6.0 }
      else mario


gravity : Float -> Model -> Model
gravity dt mario =
    { mario |
        vy <- if mario.y > 0 then mario.vy - dt/40 else 0
    }


physics : Float -> Model -> Model
physics dt mario =
    { mario |
        x <- mario.x + dt * mario.vx,
        y <- max 0 (mario.y + dt * mario.vy)
    }


walk : Keys -> Model -> Model
walk keys mario =
    { mario |
        vx <- toFloat keys.x,
        dir <-
          if  | keys.x < 0 -> Left
              | keys.x > 0 -> Right
              | otherwise  -> mario.dir
    }


-- VIEW

view : (Int, Int) -> Model -> Element
view (w',h') mario =
  let (w,h) = (toFloat w', toFloat h')

      verb =
        if  | mario.y  >  0 -> "jump"
            | mario.vx /= 0 -> "walk"
            | otherwise     -> "stand"

      dir =
        case mario.dir of
          Left -> "left"
          Right -> "right"

      src = "imgs/mario/"++ verb ++ "/" ++ dir ++ ".gif"

      marioImage = image 35 35 src

      groundY = 62 - h/2
  in
      collage w' h'
          [ rect w h
              |> filled (rgb 174 238 238)
          , rect w 50
              |> filled (rgb 74 167 43)
              |> move (0, 24 - h/2)
          , marioImage
              |> toForm
              |> Debug.trace "mario"
              |> move (mario.x, mario.y + groundY)
          ]


-- SIGNALS

main : Signal Element
main =
  Signal.map2 view Window.dimensions (Signal.foldp update mario input)


input : Signal (Float, Keys)
input =
  let delta = Signal.map (\t -> t/20) (fps 25)
      deltaArrows =
          Signal.map2 (,) delta (Signal.map (Debug.watch "arrows") Keyboard.arrows)
  in
      Signal.sampleOn delta deltaArrows
