/* AIContactIdlePlugin - no longer uses these but rather uses AIDateFormatterAditions as of 1.1 */
AILocalizedString(@"1 minute",nil);
AILocalizedString(@"%i minutes",nil)
AILocalizedString(@"1 hour",nil)
AILocalizedString(@"%i hours",nil)

/* Status preferences */
AILocalizedString(@"Status Group Deletion Confirmation",nil)
ILocalizedString(@"Are you sure you want to delete the group \"%@\" containing %i saved status items?",nil)
AILocalizedString(@"Are you sure you want to delete the group \"%@\" containing 1 saved status item?",nil)