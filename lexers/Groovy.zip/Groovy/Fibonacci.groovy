current = 1 
next    = 1 
10.times {   
   print current + ' ' 
   newCurrent = next 
   next = next + current 
   current = newCurrent 
} 
println ''
println "sssssssssssssssssssss"
