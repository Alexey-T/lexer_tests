package com.mg.groovy.samples.know

/**
 * BookBean.groovy
 *
 * @author Marcio Garcia - marcio@mangar.com.br
 */
public class BookBean{
	String title;
	String author;
	String description;
	def price;
	
}
