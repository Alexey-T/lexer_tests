package groovyx.twitter

public interface HttpMethod {
    String getText()
    String toString()
}