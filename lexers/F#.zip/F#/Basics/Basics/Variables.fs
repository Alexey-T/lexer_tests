#light

let i = 10
let s = "F#"
let c = 'c'
let b = true
let f = 3.2

let myListOfStrings = ["Granville"; "Christian"; "Rachel"]