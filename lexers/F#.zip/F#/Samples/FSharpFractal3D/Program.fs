﻿#light
open System

// Main - start the application  
[<STAThread>]
do 
  //FractalSimple.Run()
  Fractal.Run()
