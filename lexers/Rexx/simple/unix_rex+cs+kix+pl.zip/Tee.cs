﻿using System;
using System.IO;
using System.Runtime.InteropServices;

namespace RobvanderWoude
{
	class Tee
	{
		static int Main( string[] args )
		{

			#region Command Line Parsing

			string filename = String.Empty;

			if ( args.Length == 1 )
			{
				if ( args[0].IndexOf( "?" ) > -1 )
				{
					return WriteError( );
				}
				else
				{
					filename = args[0];
				}
			}
			else
			{
				if ( args.Length > 1 )
				{
					return WriteError( "Too many command line arguments" );
				}
				else
				{
					return WriteError( );
				}
			}

			#endregion

			try
			{
				if ( ConsoleEx.InputRedirected )
				{
					int inputn;
					string inputc;
					StreamWriter file = new StreamWriter( filename, true );
					do
					{
						inputn = Console.In.Read( );
						if ( inputn != -1 )
						{
							inputc = Convert.ToChar( Convert.ToByte( inputn ) ).ToString( );
							Console.Write( inputc );
							file.Write( inputc );
						}
					} while ( inputn != -1 );
					file.Close( );
				}
				return 0;
			}
			catch ( Exception e )
			{
				return WriteError( e.Message );
			}
		}


		#region Redirection Detection

		// Code to detect redirection by Hans Passant on StackOverflow.com
		// http://stackoverflow.com/questions/3453220/how-to-detect-if-console-in-stdin-has-been-redirected
		public static class ConsoleEx
		{
			public static bool OutputRedirected
			{
				get
				{
					return FileType.Char != GetFileType( GetStdHandle( StdHandle.Stdout ) );
				}
			}

			public static bool InputRedirected
			{
				get
				{
					return FileType.Char != GetFileType( GetStdHandle( StdHandle.Stdin ) );
				}
			}
			
			public static bool ErrorRedirected
			{
				get
				{
					return FileType.Char != GetFileType( GetStdHandle( StdHandle.Stderr ) );
				}
			}

			// P/Invoke:
			private enum FileType { Unknown, Disk, Char, Pipe };
			private enum StdHandle { Stdin = -10, Stdout = -11, Stderr = -12 };

			[DllImport( "kernel32.dll" )]
			private static extern FileType GetFileType( IntPtr hdl );

			[DllImport( "kernel32.dll" )]
			private static extern IntPtr GetStdHandle( StdHandle std );
		}

		#endregion

		#region Error Handling

		public static int WriteError( Exception e = null )
		{
			return WriteError( e == null ? null : e.Message );
		}

		public static int WriteError( string errorMessage )
		{
			Console.OpenStandardError( );
			if ( string.IsNullOrEmpty( errorMessage ) == false )
			{
				Console.WriteLine( );
				Console.ForegroundColor = ConsoleColor.Red;
				Console.Write( "ERROR: " );
				Console.ForegroundColor = ConsoleColor.White;
				Console.WriteLine( errorMessage );
				Console.ResetColor( );
			}

			Console.WriteLine( );
			Console.WriteLine( "Tee,  Version 1.02" );
			Console.WriteLine( "Redirect Standard Input to Standard Output AND to a file" );
			Console.WriteLine( );
			Console.Write( "Usage:  " );
			Console.ForegroundColor = ConsoleColor.White;
			Console.WriteLine( "TEE  filename" );
			Console.ResetColor( );
			Console.WriteLine( );
			Console.WriteLine( "Where:  \"filename\" is the file the Standard Input will be appended to" );
			Console.WriteLine( );
			Console.Write( "Check for redirection by Hans Passant on " );
			Console.ForegroundColor = ConsoleColor.DarkGray;
			Console.WriteLine( "StackOverflow.com" );
			Console.WriteLine( "/questions/3453220/how-to-detect-if-console-in-stdin-has-been-redirected" );
			Console.ResetColor( );
			Console.WriteLine( );
			Console.WriteLine( "Written by Rob van der Woude" );
			Console.WriteLine( "http://www.robvanderwoude.com" );
			Console.OpenStandardOutput( );
			return 1;
		}

		#endregion
	}
}
