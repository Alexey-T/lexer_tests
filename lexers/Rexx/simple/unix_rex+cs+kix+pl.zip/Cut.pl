#! perl

$syntax = "\nCut.pl,  Version 1.11\nPort of Unix' CUT command\n\n";
$syntax = $syntax."Usage:\n\nany_cmd | PERL CUT.PL [-DEBUG] ";
$syntax = $syntax."{-C:n|-F:n [-D:'any_string' [-I]]} [-L:n] [-S]\n\n";
$syntax = $syntax."Argument:           Function:";
$syntax = $syntax."                                 Dependency:\n";
$syntax = $syntax."=========           =========";
$syntax = $syntax."                                 ===========\n";
$syntax = $syntax."any_cmd             command that's output is to be parsed";
$syntax = $syntax."\n-DEBUG              display intermediate results\n";
$syntax = $syntax."                    (preferably the first argument)\n";
$syntax = $syntax."-C:<column_number>  parse by Columns or Characters\n";
$syntax = $syntax."-D:'<delimiter>'    Delimiter character or string";
$syntax = $syntax."             -F\n";
$syntax = $syntax."                    (should be escaped if necessary)\n";
$syntax = $syntax."-F:<field_number>   parse by Fields or words\n";
$syntax = $syntax."-I                  case Insensitive delimiter";
$syntax = $syntax."                -D\n";
$syntax = $syntax."-L:<length>         number of characters or words ";
$syntax = $syntax."to display  -C\n";
$syntax = $syntax."-S                  Skip blank lines in result\n\n";
$syntax = $syntax."Written by Rob van der Woude\n";
$syntax = $syntax."http://www.robvanderwoude.com\n";

# Assign default values
$case  = 1;
$debug = 0;
$delim = "\\s";
$help  = 0;
$len   = 0;
$skip  = 0;

# Command line parsing is SO much easier using regular expressions
foreach $_ ( @ARGV ) {
	if ( $debug == 1 ) {
		print "$_\n";
	}
	SWITCH: {
		if ( $_ =~ m/^-C:(\d+)$/i ) {
			$type = "char";
			$char = $1;
			last SWITCH;
		}
		if ( $_ =~ m/^-D:\'?([^.']+)\'?$/i ) {
			$delim = $1;
			last SWITCH;
		}
		if ( $_ =~ m/^-DEBUG$/i ) {
			$debug = 1;
			print "\nCommand line arguments:\n$_\n";
			last SWITCH;
		}
		if ( $_ =~ m/^-F:(\d+)$/i ) {
			$type = "word";
			$word = $1;
			last SWITCH;
		}
		if ( $_ =~ m/^-I$/i ) {
			$case = 0;
			last SWITCH;
		}
		if ( $_ =~ m/^-L:(\d+)$/i ) {
			$len = $1;
			last SWITCH;
		}
		if ( $_ =~ m/^-S$/i ) {
			$skip = 1;
			last SWITCH;
		}
		$help = 1;
	}
}

if ( !@ARGV[0] or ( $help == 1 ) ) {
	print $syntax;
	exit(1);
}

# Debug info
if ( $debug == 1 ) {
	print "\nInterpretation of command line arguments:\n";
	print "\$case=$case\n\$char=$char\n\$delim=$delim\n";
	print "\$len=$len\n\$skip=$skip\n\$type=$type\n\$word=$word\n";
}

# Create the regular expressions to parse ("cut") the string
$re = "^";
if ( $type eq "word" ) {
	if ( $case == 0 ) {
		$re = $re."^(?i)";
	}
	$re = $re."(?:$delim)*";
	if ( $word > 1 ) {
		for ( $i = 1; $i < $word; $i++ ) {
			$re = $re."[^$delim]+(?:$delim)+";
		}
	}
	$re  = $re."(";
	$re0 = $re.".*)\$";
	if ( $len > 0 ) {
		$re = $re."[^$delim]+";
		for ( $i = 1; $i < $len; $i++ ) {
			$re = $re."(?:$delim)+[^$delim]+";
		}
		$re = $re.")(?:$delim)";
	} else {
		$re = $re0;
	}
	if ( $case == 0 ) {
		$re = $re."(?-i)";
	}
} else {
# if ( $type eq "char" ) {
	if ( $char > 0 ) {
		$re  = $re.".{".( $char - 1 )."}";
		$re0 = $re."(.*)\$";
	}
	if ( $len > 0 ) {
		$re = $re."(.{0,$len})";
	} else {
		$re = $re0;
	}
}

# Debug info
if ( $debug == 1 ) {
	print "\nRegular Expression:\n$re\n";
	print "\nStandard input \& \"cut\" result:\n";
}

# Parse STDIN and display results
while ( <STDIN> ) {
	chomp $_;
	if ( $debug == 1 ) {
		print "STDIN: $_\n";
	}
	$m = $_;
	if ( $_ =~ $re ) {
		print "$1\n";
	} elsif ( $_ =~ $re0 ) {
		print "$1\n";
	} elsif ( $skip == 0 ) {
		print "\n";
	}
}
