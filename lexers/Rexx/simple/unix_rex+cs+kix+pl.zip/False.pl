#! perl

if ( @ARGV[0] ) {
	print "\nFalse.pl,  Version 1.00\n";
	print "Port of UNIX' \"false\" command\n\n";
	print "Usage:  FALSE.PL  ||  command_to_be_tested\n\n";
	print "Written by Rob van der Woude\n";
	print "http://www.robvanderwoude.com\n";
}

exit(1);
	