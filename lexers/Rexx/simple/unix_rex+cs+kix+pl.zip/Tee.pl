#! perl

# Store help text in a variable
$syntax = "\nTee.pl,  Version 2.00\n";
$syntax = $syntax."Display text on screen and redirect it to a file simultaneously\n\n";
$syntax = $syntax."Usage:  some_command  \|  PERL.EXE  TEE.PL  filename\n\n";
$syntax = $syntax."Where:  \"some_command\" is the command whose output should be redirected\n";
$syntax = $syntax."        \"filename\"     is the file the output should be redirected to\n\n";
$syntax = $syntax."Written by Rob van der Woude\nhttp://www.robvanderwoude.com\n";

# Display help and quit if no arguments were specified
if ( !$ARGV[0] ) {
	print $syntax;
	exit(1);
}

# Open file for writing, or display help text on error
open( OUT, "> $ARGV[0]" ) || die( "\nCannot open file \"$ARGV[0]\"\n\n$syntax" );

# Read and redirect standard input
while ( <STDIN> ) {
	print $_;
	print OUT $_;
}

# Close output file
close OUT;
