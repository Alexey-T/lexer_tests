function getEl( id ){
	return document.getElementById( id )
}