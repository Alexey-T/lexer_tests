(* $Id: asl.ml,v 1.1.1.1 2002/05/28 15:59:16 weis Exp $ *)

exception Error of string;;

let init_env =  ["+";"-";"*";"/";"="];;
