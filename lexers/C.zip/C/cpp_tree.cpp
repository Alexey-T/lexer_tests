class a {
int x;
void test () {
  int x;
  }
}

void main () {
int x;
}
