
void /* */ nok_func1(void) {
    return;
}

void ok_func1(void) {
    return;
}

void ok_func2(void)
{
    return;
}

void ok_func3(void) {return;}

static /* */ void ok_func4(void) {
    return;
}
