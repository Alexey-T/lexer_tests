**How to install from GitHub**

1. Click the "Download Source" button.
2. Unzip the download
3. Rename the folder to `Java Velocity`
4. Open Sublime Text 2
5. Sublime Text 2 > Preferences > Browse Packages...
6. Drag the renamed folder and drop into Packages folder
7. Marvel at the sublime goodness

---

Sublime Text 2 Package for Java Velocity Syntax
====

This is tweaked version of subtleGradient's excellent TextMate bundle https://github.com/subtleGradient/Java-Velocity.tmbundle
Primarily to add support for single-line comments

It's not an exhaustive implementation, but it's at least good enough to bother using ;)

If you notice any issues please be sure to report them!

If you're interested in taking over maintainance, do let me know.

Thanks!


[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/jampow/java-velocity/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

