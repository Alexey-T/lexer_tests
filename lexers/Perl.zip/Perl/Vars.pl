$MyVar
or $MyLib::MyVar 
or 
@MyArray
and $MyArray[0]
or $#MyArray
or
%MyHash
and $MyHash{'key'}

