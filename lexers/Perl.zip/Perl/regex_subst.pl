$sLine =~ s/x/y/; # Comment; not OK
or
$sLine =~ s/x\/y/y\*z/; # Comment; not OK
