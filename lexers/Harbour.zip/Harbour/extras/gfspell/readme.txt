Grumpfish Speller library port for Harbour.

With kind permission of author Joseph D. Booth,
Copyright (C) 1993, All Rights Reserved.

------------------------------------------------------------------------
From: (Joe jbooth-consulting com)
Subject: Re: Grumpfish Speller within xHarbour.

No problem giving you permission, feel free to use Grumpfish Speller in
its revised form.  Also, feel free to release it to the xHarbour
community.  Now a question for you.   Can I either add a link from my web
site to your site where xHarbour users can download the .LIB or get a copy
of the .LIB that I can post on website for download?    I would like
people who visit my site to be aware of the xHarbour version and how to
get it...

If you need any kind of legal document besides this e-mail, feel free to
fax it to 610-409-8859 (USA #), and I'll be happy to sign it for you.
However, as far as I am concerned,  you are free to use the library and to
make it available to any xHarbour users...

Thanks

Also, thanks for the kind words about the speller, nice to hear...
------------------------------------------------------------------------

Porting to Harbour done by:
   Les Hughes
   Viktor Szakats

[vszakats]
