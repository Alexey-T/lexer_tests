uHTTPD micro web server

Build it without GD: hbmk2 uhttpd.hbp   modules.hbp
Build it with    GD: hbmk2 uhttpdgd.hbp modulesg.hbp
  [ This one needs GD lib. Please download it from:
    http://www.libgd.org/ ]

To see accepted parameters run: uhttpd -?
Parameters can also be defined using uhttpd.ini file.

Once started connect to uhttpd using:
http://localhost:8082
to see default index page.

Francesco
