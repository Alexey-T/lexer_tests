#include "hbapi.h"

/* Public API implemented in C */

HB_FUNC( HBTPL_MYPUBLICFUNCTION_IN_C )
{
   hb_retc( "It works from C" );
}
