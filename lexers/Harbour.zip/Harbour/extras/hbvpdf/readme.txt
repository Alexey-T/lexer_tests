Welcome to _pure_ Clipper Pdf Library!

Changes in Release 0.08
1. Fixed page buffer string overflow.
*********************************************************************
Changes in Release 0.07a
1. Fixed minor errors with JPEG function to work properly with GRAY & RGB
*********************************************************************
Changes in Release 0.07.
1. Fixed minor errors
Changes in Release 0.06.
1. Added new function pdfBox1 for colorful boxes
2. Added new page to demo program
*********************************************************************
Changes in Release 0.05.
All changes commented as // 0.04.
1. Added #ifdef - #endif for Harbour support (see end of file pdf.prd)
2. Fixed minor error for allow different page sizes (A4, ...)
*********************************************************************
Changes in Release 0.04.
All changes commented as // 0.04.
1. Added Courier font.
2. TOP, LEFT, BOTTOM changed to PDFTOP, PDFLEFT, PDFBOTTOM to avoid conflicts.
All changes commented as // 0.04.
**** Please note 3 most popular fonts now available: Times, Helvetica
, Courier. When you calling pdfSetFont, please use only above names.
*********************************************************************
Changes in Release 0.03.
Replaced function from Clipper Tools and Nanfor for Clipper Source.
*********************************************************************
This is first public release 0.02.
*********************************************************************
Please send your comments on
andvit@sympatico.ca

Thank you
