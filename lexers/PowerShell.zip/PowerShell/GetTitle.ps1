# Inspired by Aaron Lerch's blog post
# http://www.aaronlerch.com/blog/2007/02/16/powershell-window-title/
write-host $Host.UI.RawUI.WindowTitle
