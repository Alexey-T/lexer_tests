#include <stdio.h>
void VerifyC(void)
{
  printf("VerifyC\n");
}
