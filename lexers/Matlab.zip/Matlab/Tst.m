classdef classname
   properties
      PropName
   end
   methods
      methodName
   end
   events
      EventName
   end
   enumeration
      EnumName (arg)
   end
end

while expression
   statements
end

switch switch_expression
   case case_expression
      statements
   case case_expression
      statements
    :
   otherwise
      statements
end

try
   statements
catch exception
   statements
end
