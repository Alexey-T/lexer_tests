def pp:
    def action1():
        pass
    def action1():
        pass
    def action1():
        pass
        pass
        pass
 def bb:
  def aa:
    def action1('def def'):
        pass00
    def action1('def'):
        pass1
    def action2('deff'):
      def dd:
        dd
      def cc:
        pass2
