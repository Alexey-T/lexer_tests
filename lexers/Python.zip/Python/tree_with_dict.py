class Class():
  Dict = {0: 'a', 1: 'b', 2: 'c'}
  def method(self):
    Dict = {0: 'a', 1: 'b', 2: 'c'}
        