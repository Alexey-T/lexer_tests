class AA:
    def aa(aa,
           bb):
        pass
        
    def bb(test,
           test2):
        pass