{
  'keyword_case': 'lower', # [None, 'upper', 'lower', 'capitalize']
  'identifier_case': None, # [None, 'upper', 'lower', 'capitalize']
  'strip_comments': False, # [True, False]
  'strip_whitespace': False, # [True, False]
  'indent_tabs': False, # [True, False]
  'indent_width': 22, # int>0
  'reindent': True, # [True, False]
  'right_margin': None # None, int>=10
}
