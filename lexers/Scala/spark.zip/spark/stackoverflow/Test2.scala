package com.sparkbyexamples.spark.stackoverflow

import org.apache.spark.sql.SparkSession

object Test2 {

//  def main(args: Array[String]): Unit = {
//
//    val spark = SparkSession.builder()
//      .master("local[1]")
//      .appName("SparkByExample")
//      .getOrCreate();
//
//    val peopleDFCsv = spark.read.format("csv")
//      .load("src/main/resources/stack.csv")
//
//    val d = peopleDFCsv.map(row=>{
//      val col1=row.get(1)
//      val col2=row.get(1)
//      (col1,col2)
//    }).toDF()
//
//  }
}
